#include <iostream>

//one-line comment

/*
 * multiple-line
 * comment
 */

using namespace std;

int main() {
	//displays Hello World! on the screen
    std::cout << "Hello World!";
    return 0;
}
