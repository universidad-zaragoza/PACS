#include <iostream>

int func() {
    std::cout << "This is my func" << std::endl;
    return 0;
}
